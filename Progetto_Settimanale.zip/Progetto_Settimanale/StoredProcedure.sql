-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- Esecuzione della query con un valore specifico per il parametro

-- Creo una query parametrica che visualizzi Data violazione, Importo e decurta mento punti relativi ad una certa data
DECLARE @dataViolazione DATE = '2024-02-01'; 

SELECT
Dataviolazione AS DataViolazione,
Importo,
DecurtamentoPunti
FROM
Verbale
WHERE
Dataviolazione = @dataViolazione;

-- Una SP parametrica che, ricevendo in input un anno, visualizzi l�elenco delle contravvenzioni effettuate in un quel determinato anno
DECLARE @AnnoViolazione DATE = '2024';

SELECT
DataVerbale AS DataViolazione,
Importo,
DecurtamentoPunti,
COUNT(*) AS ContrAnnue
FROM 
Verbale
WHERE
YEAR(Dataviolazione) = YEAR(@AnnoViolazione)
GROUP BY 
Nominativo_Agente, DataVerbale, Importo, DecurtamentoPunti;

-- Una SP parametrica che, ricevendo in input una data, visualizzi il totale dei punti decurtati in quella determinata data
DECLARE @AnnoDecurtamento DATE = '2024-02-09';

SELECT 
DataVerbale,
SUM(DecurtamentoPunti) AS TotalePuntiDecurtati
FROM 
Verbale
WHERE
DataVerbale = @AnnoDecurtamento
GROUP BY 
DataVerbale, DecurtamentoPunti;

-- Una SP che consenta di eliminare un determinato verbale identificandolo con il proprio identificativo. 
DECLARE @idRemove INT = 5;

DELETE FROM Verbale
WHERE idVerbale = @idRemove;




