-- Seleziono tutti i verbali fatti
SELECT COUNT(*) 
FROM Verbale AS elencoverbali

-- Conto i verbali trascritti raggruppati per anagrafe 

Select count (*) 
From Verbale as VerbaliperAnag 
group by IDanagrafica

-- Conto i verbali trascritti raggruppati per violazione

Select count (*) 
From Verbale as VerbaliperAnag 
group by IDviolazione

-- Calcolo i punti decurtati per ogni persona
SELECT 
IDAnagrafica, 
SUM(DecurtamentoPunti) AS TotalePuntiDecurtati 
FROM Verbale GROUP BY IDAnagrafica

-- Estraggo, usando il metodo JOIN. Nome, Cognome, Indirizzo, DataViolazione,  Indirizzo Violazione, importo e punti decurtati per tutte le persone di Palermo
SELECT 
A.Nome, 
A.Cognome, 
A.Citta,
A.Indirizzo AS IndirizzoPersona, 
V.IndirizzoViolazione AS IndirizzoViolazione, 
V.Dataviolazione AS DataViolazione, 
V.Importo, 
V.DecurtamentoPunti
FROM 
Verbale V
JOIN 
Anagrafica A ON V.IDAnagrafica = A.IDAnagrafica
WHERE 
A.Citta ='Palermo'
-- Estraggo, usando il metodo JOIN. Nome, Cognome, Indirizzo, DataViolazione,  importo e punti decurtati fatte tra febbraio e luglio 2024 (non ho dati per il 2009)
SELECT 
A.Nome, 
A.Cognome, 
A.Indirizzo AS IndirizzoPersona, 
V.IndirizzoViolazione AS IndirizzoViolazione, 
V.Dataviolazione AS DataViolazione, 
V.Importo, 
V.DecurtamentoPunti
FROM 
Verbale V
JOIN 
Anagrafica A ON V.IDAnagrafica = A.IDAnagrafica
WHERE 
V.Dataviolazione >= '2024-02-01' AND V.Dataviolazione <= '2024-07-31';

-- Calcolo il totale da pagare, usando anche qui Join, per singola persona
SELECT
A.Nome,
A.Cognome,
A.Indirizzo AS IndirizzoPersona,
SUM(V.Importo) AS TotaleDaPagare
FROM
Verbale V
JOIN
Anagrafica A ON V.IDAnagrafica = A.IDAnagrafica
GROUP BY
V.IDAnagrafica, A.Nome, A.Cognome, A.Indirizzo

-- Estraggo tutte le persone che vivono a Palermo
SELECT * FROM Anagrafica WHERE citta = 'Palermo'

--  Conteggio delle violazioni per Data Verbale raggruppate per Nominativo dell�agente di Polizia (al posto delle contestazioni) 
SELECT 
Nominativo_Agente,
DataVerbale,
COUNT(*) AS NumeroVerbaliPerAgenteinData
FROM 
Verbale
GROUP BY 
Nominativo_Agente, DataVerbale;

-- Estraggo Cognome, Nome, Indirizzo, Data violazione, Importo e punti decurtati per tutte le violazioni che superino il decurtamento di 5 punti

SELECT 
A.Cognome, 
A.Nome, 
A.Indirizzo AS IndirizzoPersona, 
V.Dataviolazione AS DataViolazione, 
V.Importo, 
V.DecurtamentoPunti
FROM 
Verbale V
JOIN 
Anagrafica A ON V.IDAnagrafica = A.IDAnagrafica
WHERE 
V.DecurtamentoPunti >= 5 -- Esce vuota perch� non ho infrazioni > 5

-- Estraggo Cognome, Nome, Indirizzo, Data violazione, Importo e punti decurtati per tutte le violazioni che superino l�importo di 400 euro. 

SELECT 
A.Cognome, 
A.Nome, 
A.Indirizzo AS IndirizzoPersona, 
V.Dataviolazione AS DataViolazione, 
V.Importo, 
V.DecurtamentoPunti
FROM 
Verbale V
JOIN 
Anagrafica A ON V.IDAnagrafica = A.IDAnagrafica
WHERE 
V.Importo > 400
